import { QrcodePlaceholder } from "@/components/QrcodePlaceholder";

export default function Page() {
  return <QrcodePlaceholder />;
}
