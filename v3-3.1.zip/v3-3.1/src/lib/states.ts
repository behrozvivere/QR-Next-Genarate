import { atom } from "jotai";
import { qrStyleList } from "@/lib/qr_style_list";

export const urlAtom = atom<string>("");
